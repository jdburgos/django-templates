""" services:
  {{ project_name }}-db:
    image: 'postgres:latest'
    container_name: {{ project_name }}-db
    restart: always
    ports:
      - '5435:5432'
    environment:
      - 'POSTGRES_DB=${DB_NAME}'
      - 'POSTGRES_USER=${DB_USER}'
      - 'POSTGRES_PASSWORD=${DB_PASSWORD}'
    volumes:
      - 'postgres-data:/var/lib/postgresql/data'
    networks:
      {{ project_name }}_network:
        aliases:
          - {{ project_name }}-postgresql-host
  {{ project_name }}-pgadmin:
    image: 'dpage/pgadmin4:latest'
    container_name: {{ project_name }}-pgadmin
    restart: always
    ports:
      - '82:80'
    environment:
      - 'PGADMIN_DEFAULT_EMAIL=${PGADMIN_USER}'
      - 'PGADMIN_DEFAULT_PASSWORD=${PGADMIN_PASSWORD}'
    volumes:
      - 'pgadmin-data:/var/lib/pgadmin'
    networks:
      {{ project_name }}_network:
        aliases:
          - {{ project_name }}-pgadmin-host
    depends_on:
      - {{ project_name }}-db
  {{ project_name }}-api:
    build:
      context: .
      args:
        - 'DEV=${DEV}'
    container_name: {{ project_name }}-api
    restart: always
    ports:
      - '8005:8000'
    environment:
      - 'DB_NAME=${DB_NAME}'
      - 'DB_USER=${DB_USER}'
      - 'DB_PASSWORD=${DB_PASSWORD}'
      - 'DB_HOST=${DB_HOST}'
      - 'DB_PORT=${DB_PORT}'
      - 'SECRET_KEY=${SECRET_KEY}'
      - 'DEBUG=${DEBUG}'
    networks:
      {{ project_name }}_network:
        aliases:
          - api-host
    depends_on:
      - {{ project_name }}-db
volumes:
  postgres-data:
    driver: local
  pgadmin-data:
    driver: local
networks:
  {{ project_name }}_network:
    driver: bridge
 """