# database
DB_NAME=
DB_USER=
DB_PASSWORD=
DB_HOST=
DB_PORT=

# pgadmin
PGADMIN_USER=
PGADMIN_PASSWORD=

# django
SECRET_KEY={{ secret_key }}
DEBUG=

# docker
DEV=
