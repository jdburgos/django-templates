from drf_yasg import openapi
from drf_yasg.views import get_schema_view
from rest_framework_simplejwt.authentication import JWTAuthentication

schema_view = get_schema_view(
    openapi.Info(
        title="API",
        default_version="v1",
        description="Api for get info.",
        contact=openapi.Contact(email="admin@test.com"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
    authentication_classes=(JWTAuthentication,),
)
