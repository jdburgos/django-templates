# Install os dependencies (linux)

sudo apt install python3-pip python3-dev libpq-dev

# Env variables
create a file in the root '.env' or '.env.prod' create the docker image.

``` dotenv
# database
DB_NAME=
DB_USER=
DB_PASSWORD=
DB_HOST=
DB_PORT=

# pgadmin
PGADMIN_USER=
PGADMIN_PASSWORD=

# django
SECRET_KEY=
DEBUG=

# docker
DEV=
```
